
const Project=()=>{

    return(
        <>
        <div style={{height:"80px",width:"100%", backgroundColor:"pink" ,margin:"-100px 0px 0px 0px "}}></div>
        <img className="img1"  src="https://bestfreehtmlcsstemplates.com/uploads/templates-images/577eda999db794e52271a9e435c2395c.jpeg"/>
        
        <img className="img2"  src="https://images.all-free-download.com/images/thumbjpg/luxury_watch_discount_landing_page_template_elegant_dark_6937346.jpg"/>
        
        <img className="img3"  src="https://i0.wp.com/themes.svn.wordpress.org/modern-ecommerce/6.4/screenshot.png"/>

        <div className="text1">Single Page Website </div>
        <div  className="text2">Multiple Page Website </div>
        <div  className="text3">Ecommerce Website </div>

        <div className="project"></div>
        </>
    )
}
export default Project;