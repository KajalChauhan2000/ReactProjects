  

  const Home=()=>{
    
    return(
        <>
        <h1>Welcome to My Home Page</h1>
        </>
    )
}
export default Home;