 

 const Product=()=>{
    
    return(
        <>
        <h1>Welcome to My Product Page</h1>
        </>
    )
}
export default Product;