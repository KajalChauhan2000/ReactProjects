
const AboutSelling=()=>{
    
    return(
        <>
        <h1>Welcome to My AboutSelling Page</h1>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore eveniet dicta, hic aut suscipit doloribus? Omnis natus quia architecto <br/>
        voluptatum eveniet possimus unde minima laborum, et libero laudantium reprehenderit hic.

        <hr/>

        </>
    )
}
export default AboutSelling;