

  

  const Cart=()=>{
    
    return(
        <>
        <h1>Welcome to My Cart Page</h1>
        </>
    )
}
export default Cart;