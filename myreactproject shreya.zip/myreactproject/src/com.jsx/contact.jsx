

const Contact=()=>{
    
    return(
        <>
        <h1>Welcome to My Contact Page</h1>
        </>
    )
}
export default Contact;